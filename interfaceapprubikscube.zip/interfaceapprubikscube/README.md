## Compte google

https://blog.rolandl.fr/2015-02-15-mettre-en-place-la-connexion-google-plus-dans-une-application-android.html

## gestion ecran
https://www.developpez.net/forums/d1098227/java/general-java/java-mobiles/android/android-detecter-doigts/  
https://cyrilmottier.com/2009/05/06/la-gestion-des-touchevents/  
https://developer.android.com/reference/android/view/View.OnTouchListener  
https://developer.android.com/reference/android/view/MotionEvent  